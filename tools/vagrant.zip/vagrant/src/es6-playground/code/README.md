# ES6 Playground

This folder is setup to work with ES6 and babel and is configured using the Stage 2 and ES2015 presets.

Details of how this folder was configured are available [here](https://gist.github.com/kenmazaika/c85f3f7e229aed9a75fda5fc314da402).