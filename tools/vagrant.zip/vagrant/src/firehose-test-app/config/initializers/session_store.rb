# Be sure to restart your server when you modify this file.

FirehoseTestApp::Application.config.session_store :cookie_store, key: '_firehose-test-app_session'
